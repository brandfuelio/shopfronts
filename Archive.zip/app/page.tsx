"use client"

import Component from "../digital-store-pixel-perfect"

export default function Page() {
  return <Component />
}
